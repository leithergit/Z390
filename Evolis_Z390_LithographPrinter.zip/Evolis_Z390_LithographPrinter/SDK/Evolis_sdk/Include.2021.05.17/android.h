﻿#ifndef EVOLIS_ANDROID_H
#define EVOLIS_ANDROID_H

#include <jni.h>
#include "evolis.h"
EVOLIS_LIB void evolis_set_android_env(JNIEnv* env, jobject androidContext);

#endif // EVOLIS_ANDROID_H
