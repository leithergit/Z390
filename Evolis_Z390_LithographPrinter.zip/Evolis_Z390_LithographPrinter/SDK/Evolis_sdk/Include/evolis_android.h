#ifndef EVOLIS_ANDROID_H
#define EVOLIS_ANDROID_H
#ifdef __ANDROID__

#include <jni.h>

typedef struct evolis_device_s {
    int     vid;
    int     pid;

    char    productName[128];
    char    deviceName[128];

    jobject device;
} evolis_device_t;

EVOLIS_LIB void evolis_set_android_env(JNIEnv* env, jobject androidContext);

EVOLIS_LIB jobject evolis_get_usb_manager();

EVOLIS_LIB void evolis_get_device_list(evolis_device_t*** devices);
EVOLIS_LIB void evolis_free_device_list(evolis_device_t** devices);

#endif // __ANDROID__
#endif // EVOLIS_ANDROID_H
