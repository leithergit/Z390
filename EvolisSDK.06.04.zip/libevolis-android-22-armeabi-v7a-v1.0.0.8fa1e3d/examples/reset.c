#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    if (evolis_reset(printer, 0, NULL) == 0)
        printf("reset ok\n");
    else
        printf("reset error\n");
    if (avansia_hw_reset(printer, 0, NULL) == 0)
        printf("hard reset ok\n");
    else
        printf("hard reset error\n");
}
