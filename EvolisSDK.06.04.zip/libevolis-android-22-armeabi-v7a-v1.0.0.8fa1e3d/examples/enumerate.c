#include "evolis.h"

#include <stdlib.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 0;

static char* tocstring(char* dest, const wchar_t* src)
{
    int n = wcslen(src);

    wcstombs(dest, src, n);
    dest[n] = '\0';
    return dest;
}

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(printer);
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_device_t* devices;
    int              n;

    if ((n = evolis_get_devices(&devices, 0, 0)) >= 0) {
        printf("%d printers found\r\n", n);
        for (int i = 0; i < n; ++i) {
            char id[64];
            char name[64];

            printf("- %s\r\n", tocstring(name, devices[i].name));
            printf("  Id: %s\r\n", tocstring(id, devices[i].id));
            printf("  Mark: %s\r\n", evolis_get_mark_name(devices[i].mark));
            printf("  Model: %s\r\n", evolis_get_model_name(devices[i].model));
            printf("  isSupervised: %s\r\n", (devices[i].isSupervised) ? "true" : "false");
            printf("  link: %s\r\n",
                    (devices[i].link == EVOLIS_LI_TCP) ? "TCP" :
                    (devices[i].link == EVOLIS_LI_USB) ? "USB" : "?");
        }
    }
}
