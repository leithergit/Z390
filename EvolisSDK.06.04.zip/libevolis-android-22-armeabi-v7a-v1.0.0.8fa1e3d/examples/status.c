#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_EVOLIS;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_status_t es;
    int             r;

    r = evolis_status(printer, &es);
    printf("r=%d", r);
}
