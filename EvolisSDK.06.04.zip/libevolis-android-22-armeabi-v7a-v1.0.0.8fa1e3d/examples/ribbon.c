#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_ribbon_t er;

    evolis_get_ribbon(printer, &er);
    printf("Ribbon:\n");
    printf("  description   = %s\n", er.description);
    printf("  zone          = %s\n", er.zone);
    printf("  type          = %d\n", er.type);
    printf("  capacity      = %d\n", er.capacity);
    printf("  remaining     = %d\n", er.remaining);
    printf("  progress      = %d%%\n", er.progress);
    printf("  productCode   = %s\n", er.productCode);
    printf("  batchNumber   = %d\n", er.batchNumber);
    printf("  buildAt       = %s\n", er.buildAt);
}
