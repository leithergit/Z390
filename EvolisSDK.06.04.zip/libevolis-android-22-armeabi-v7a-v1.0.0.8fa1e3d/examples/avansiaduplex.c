#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AVANSIA;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_set_input_tray(printer, EVOLIS_IT_FEEDER);
    evolis_set_output_tray(printer, EVOLIS_OT_STANDARD);
    evolis_print_set_imagep(printer, EVOLIS_FA_FRONT, "resources/front.bmp");
    evolis_print_set_imagep(printer, EVOLIS_FA_BACK, "resources/back.bmp");
    evolis_print_exec(printer);
}
