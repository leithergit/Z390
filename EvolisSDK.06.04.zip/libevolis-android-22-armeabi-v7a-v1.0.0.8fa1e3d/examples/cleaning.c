#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    evolis_cleaning_t ec;

    if (evolis_get_cleaning(printer, &ec) == 0) {
        printf("Cleaning:\n");
        printf("  totalCardCount = %d\n", ec.totalCardCount);
        printf("\n");
        printf("  cardCount                     = %d\n", ec.cardCount);
        printf("  cardCountBeforeWarning        = %d\n", ec.cardCountBeforeWarning);
        printf("  cardCountBeforeWarrantyLost   = %d\n", ec.cardCountBeforeWarrantyLost);
        printf("\n");
        printf("  regularCleaningCount  = %d\n", ec.regularCleaningCount);
        printf("  advancedCleaningCount = %d\n", ec.advancedCleaningCount);
        printf("\n");
        printf("  printHeadUnderWarranty = %d\n", ec.printHeadUnderWarranty);
    }
}
