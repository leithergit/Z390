#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 0;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(printer);
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_image_t* img;

    if ((img = evolis_image_new()) != NULL) {
        evolis_draw_imagep(img, "resources/grid-100x100.png", 0);

        evolis_set_ratio(img, EVOLIS_RT_IGNORE);
        evolis_set_bounding_box(img, 0, 0, 600, 600);
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);

        evolis_set_ratio(img, EVOLIS_RT_EXPAND);
        evolis_set_bounding_box(img, 700, 0, 600, 600);
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);

        evolis_set_ratio(img, EVOLIS_RT_KEEP);
        evolis_set_bounding_box(img, 0, 700, 600, 600);
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);
        evolis_set_bounding_box(img, 700, 700, 600, 300);
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);
        evolis_set_bounding_box(img, 1400, 700, 300, 600);
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);

        evolis_renderp(img, "designed.jpg");
        evolis_image_delete(img);
    }
}
