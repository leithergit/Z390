#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AVANSIA;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    evolis_set_input_tray(printer, EVOLIS_IT_FEEDER);
    evolis_set_output_tray(printer, EVOLIS_OT_STANDARD);
    evolis_print_set_imageb(printer, EVOLIS_FA_FRONT, bmp, bmpSize);
    evolis_print_exec(printer);
}
