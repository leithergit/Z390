#include <evolis.h>
#include <string.h>

evolis_type_t g_printer_type = EVOLIS_TY_EVOLIS;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    for (int i = 0; i < 40; ++i) {
        char cmd[32];
        char buffer[1024];
        int  n;

        if ((i % 5) == 0)
            strcpy(cmd, "Rfv");
        else if ((i % 5) == 1)
            strcpy(cmd, "Rip");
        else if ((i % 5) == 2)
            strcpy(cmd, "Regw");
        else if ((i % 5) == 3)
            strcpy(cmd, "Rtp");
        else
            strcpy(cmd, "Renm");
        n = evolis_command(printer, cmd, strlen(cmd), buffer, sizeof buffer);
        printf("> n=%d cmd=%4s buffer=%s\n", n, cmd, buffer);
    }
}
