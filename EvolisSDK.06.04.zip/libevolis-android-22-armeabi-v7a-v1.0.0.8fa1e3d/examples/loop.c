#include <evolis.h>

#ifdef _WIN32
#  include <Windows.h>
#endif // _WIN32

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    for (int i = 0; i < 1024; ++i) {
        evolis_major_state_t major;
        evolis_minor_state_t minor;
        int                  r;

        r = evolis_get_state(printer, &major, &minor);
        if (r == 0) {
            printf("> %03d: Printer state:\n", i);
            printf("  - Major: %s\n", evolis_get_major_string(major));
            printf("  - Minor: %s\n", evolis_get_minor_string(minor));
        } else {
            printf("/ %03d: Error getting printer status.\n", i);
        }
        fflush(stdout);
#ifdef _WIN32
        Sleep(500);
#endif // _WIN32
    }
}
