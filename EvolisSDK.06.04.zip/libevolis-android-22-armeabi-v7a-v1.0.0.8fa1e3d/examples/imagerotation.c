#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 0;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(printer);
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_image_t* img;

    if ((img = evolis_image_new()) != NULL) {
        evolis_draw_imagep(img, "resources/landscape.jpg", 0);

        evolis_set_ratio(img, EVOLIS_RT_KEEP);

        evolis_set_bounding_box(img, 200, 200, 900, 900);
        evolis_draw_imagep(img, "resources/front.bmp", 45);

        evolis_set_barcode(img, EVOLIS_BC_CODE128, 40, 0);
        evolis_set_bounding_box(img, 1024, 0, 1024, 1300);
        evolis_draw_barcode(img, 90, "0123456789");

        evolis_renderp(img, "designed.jpg");
    }
}
