#include <evolis.h>
#include <stdio.h>

evolis_type_t g_printer_type = EVOLIS_TY_EVOLIS;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    evolis_status_t es;
    char            reply[3];
    int             printed = 0;

    evolis_command(printer, "Psoe;e", 6, reply, sizeof(reply));
    evolis_set_input_tray(printer, EVOLIS_IT_FEEDER);
    evolis_print_set_imageb(printer, EVOLIS_FA_FRONT, bmp, bmpSize);
    evolis_print_exec(printer);
    while (!printed) {
        if (evolis_status(printer, &es) != 0) {
            printf("Error reading printer status\n");
            return ;
        }
        printf("====> es.information=%d %d", es.information, EVOLIS_INF_BUSY);
        printed = !(es.information & EVOLIS_INF_BUSY);
    }
}
