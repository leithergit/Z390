#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 0;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(printer);
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_image_t* img;

    if ((img = evolis_image_new()) != NULL) {
        evolis_draw_imagep(img, "resources/grid-100x100.png", 0);

        evolis_set_font(img, EVOLIS_FT_SIMPLEX, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 100, 0, "SIMPLEX");

        evolis_set_font(img, EVOLIS_FT_PLAIN, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 200, 0, "PLAIN");

        evolis_set_font(img, EVOLIS_FT_DUPLEX, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 300, 0, "DUPLEX");

        evolis_set_font(img, EVOLIS_FT_COMPLEX, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 400, 0, "COMPLEX");

        evolis_set_font(img, EVOLIS_FT_TRIPLEX, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 500, 0, "TRIPLEX");

        evolis_set_font(img, EVOLIS_FT_COMPLEX_SMALL, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 0, 600, 0, "COMPLEX_SMALL");

        evolis_set_fontp(img, "resources/OCR-AREGULAR.ttf", 84, 0x1E5AA5);
        evolis_draw_text(img, 0, 700, 0, "CUSTOM FONT");

        evolis_set_font(img, EVOLIS_FT_ITALIC, 3, 0x1E5AA5, 3);
        evolis_draw_text(img, 800, 0, 45, "ITALIC (with rotation)");

        evolis_set_fontp(img, "resources/OCR-AREGULAR.ttf", 84, 0x1E5AA5);
        evolis_draw_text(img, 800, 100, 45, "CUSTOM FONT");

        evolis_renderp(img, "designed.jpg");
    }
}
