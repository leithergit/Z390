#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_infos_t infos;

    if (evolis_get_infos(printer, &infos) == 0) {
        printf("name     =%s\n", infos.nameA);
        printf("type     =%d\n", infos.type);
        printf("modelName=%s\n", infos.modelName);
        printf("modelId  =%d\n", infos.modelId);
        printf("fwVersion=%s\n", infos.fwVersion);
        printf("serialNum=%s\n", infos.serialNumber);
        printf("hasEthern=%d\n", infos.hasEthernet);
        printf("hasWifi  =%d\n", infos.hasWifi);
        printf("hasFlip  =%d\n", infos.hasFlip);
        printf("hasLamina=%d\n", infos.hasLaminator);
        printf("hasMagEnc=%d\n", infos.hasMagEnc);
        printf("hasSmartE=%d\n", infos.hasSmartEnc);
        printf("hasContac=%d\n", infos.hasContactLessEnc);
    }
}
