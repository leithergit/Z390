#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_major_state_t major;
    evolis_minor_state_t minor;
    int                  r;

    r = evolis_get_state(printer, &major, &minor);
    if (r == 0) {
        printf("Printer state:\n");
        printf("  - Major: %s\n", evolis_get_major_string(major));
        printf("  - Minor: %s\n", evolis_get_minor_string(minor));
    }
}
