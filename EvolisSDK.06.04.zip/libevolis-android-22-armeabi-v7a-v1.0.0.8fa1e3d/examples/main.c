#include <evolis.h>
#include <evolis_p.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

extern evolis_type_t g_printer_type;
extern int g_printer_enabled;

void example(evolis_t* printer, const char* bmp, size_t bmpSize);

int main(int argc, char** argv)
{
    char*       bmp;
    size_t      bmpSize;
    evolis_t*   printer;
    const char* device = (argc > 1) ? argv[1] : "usb:///dev/usb/lp0";
    int         type   = (argc > 2) ? atoi(argv[2]) : (int) g_printer_type;

    evolis_set(EVOLIS_OP_PRNFILE, "tmp/output.prn");
    evolis_set(EVOLIS_OP_BMPFILE, "tmp/%s-face.bmp");

    evolis_log_set_level(EVOLIS_LG_DEBUG);
    evolis_log_set_level(EVOLIS_LG_ERROR);

    if (g_printer_enabled == 1) {
        if (evolis_file_read("resources/front.bmp", &bmp, &bmpSize) == -1) {
            printf("Error: can't open bmp file.\n");
            return 1;
        }

        if ((printer = evolis_open2(device, type)) != NULL) {
            example(printer, bmp, bmpSize);
            evolis_close(printer);
        } else {
            printf("Error: %s - %s\n", evolis_last_error_string(), strerror(errno));
        }

        evolis_file_free(bmp);
    } else {
        example(NULL, NULL, 0);
    }

    return 0;
}
