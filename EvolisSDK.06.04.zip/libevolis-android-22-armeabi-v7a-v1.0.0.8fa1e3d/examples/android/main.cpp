#include "evolis.h"
#include "android.h"

#include <QAndroidJniEnvironment>
#include <QAndroidJniObject>
#include <QApplication>
#include <QCheckBox>
#include <QDebug>
#include <QHBoxLayout>
#include <QList>
#include <QPair>
#include <QTextEdit>
#include <QTimer>
#include <QtAndroid>

#include <unistd.h>

#define MAKE_NEW_CONNECTION auto connection = evolis_open(device->name, false);
//#define MAKE_NEW_CONNECTION auto connection = evolis_open(L"Evolis Primacy", false); EVOLIS_UNUSED_ATTR(device);
//#define MAKE_NEW_CONNECTION auto connection = evolis_open2("usb://Evolis/Primacy", EVOLIS_TY_EVOLIS); EVOLIS_UNUSED_ATTR(device);

extern char gColorBmp[];
extern unsigned int gColorBmpLen;

extern char gBlackBmp[];
extern unsigned int gBlackBmpLen;

static QTextEdit* _console = NULL;
static QCheckBox* _autoScrollCb = NULL;

static void _log(const QString& message)
{
    _console->insertPlainText(message + "\n");
    if (_autoScrollCb->isChecked())
        _console->moveCursor(QTextCursor::End);
    qApp->processEvents();
    qApp->processEvents(); // must be called twice to be sure ui is refreshed :(
    qDebug() << message;
}

static void _openCloseTest(evolis_device_t* device)
{
    _log("-- _openCloseTest()");
    for (int i = 0; i < 20480; ++i) {
        MAKE_NEW_CONNECTION;
        evolis_major_state_t major;
        evolis_minor_state_t minor;
        int r = -1;

        if (connection != NULL) {
            r = evolis_get_state(connection, &major, &minor);
            evolis_close(connection);
        }
        qDebug(">> i=%d, connection=0x%X state=%s", i, connection, (r == 0) ? "OK" : "FAILED");
    }
}

static void _rokTest(evolis_device_t* device)
{
    MAKE_NEW_CONNECTION;
    char reply[32];
    int  r;

    _log("-- _rokTest()");
    if (connection != NULL) {
        for (int i = 0; i < 20480; ++i) {
            reply[0] = '\0';
            r = evolis_command(connection, "Rok", 3, reply, sizeof(reply));
            qDebug(">> i=%d, r=%d, reply=%s", i, r, reply);
        }
        evolis_close(connection);
    }
}

static void _cardMovementsTest(evolis_device_t* device)
{
    static const QList<QPair<evolis_pos_t, const char*>> positions = {
        {EVOLIS_CP_INSERT, EVOLIS_STR(EVOLIS_CP_INSERT)},
        {EVOLIS_CP_CONTACT, EVOLIS_STR(EVOLIS_CP_CONTACT)},
        {EVOLIS_CP_CONTACTLESS, EVOLIS_STR(EVOLIS_CP_CONTACTLESS)},
        {EVOLIS_CP_EJECT, EVOLIS_STR(EVOLIS_CP_EJECT)},
    };
    MAKE_NEW_CONNECTION;

    _log("-- _cardMovementsTest()");
    if (connection != NULL) {
        for (int i = 0; i < 200; ++i) {
            evolis_pos_t pos = positions[i % 4].first;
            const char*  posName = positions[i % 4].second;
            int r = evolis_set_card_pos(connection, pos);
            qDebug(">> i=%d, pos=%d/%s r=%d", i, pos, posName, r);
        }
        evolis_close(connection);
    }
}

static void _printerResetTest(evolis_device_t* device)
{
    MAKE_NEW_CONNECTION;

    _log("-- _printResetTest()");
    if (connection != NULL) {
        evolis_reset(connection, 0, NULL);
        evolis_set_card_pos(connection, EVOLIS_CP_INSERTEJECT);
        evolis_close(connection);
    }
}

static void _printImage(evolis_device_t* device)
{
    MAKE_NEW_CONNECTION;

    _log("-- _printImage()");
    if (connection != NULL) {
        int r;

        // Color printing.
        evolis_print_set_imageb(connection, EVOLIS_FA_FRONT, gColorBmp, gColorBmpLen);
        r = evolis_print_exec(connection);
        // if r == 0 => success

        // Black printing.
        evolis_print_set_imageb(connection, EVOLIS_FA_FRONT, gBlackBmp, gBlackBmpLen);
        r = evolis_print_exec(connection);
        // if r == 0 => success

        evolis_close(connection);
    }
}

int main(int argc, char** argv)
{
    QApplication app(argc, argv);
    app.setOrganizationName("Evolis");
    app.setOrganizationDomain("evolis.com");
    app.setApplicationName("LibEvolis");

    QAndroidJniEnvironment jniEnv;
    QAndroidJniObject androidCtx = QtAndroid::androidContext();
    evolis_set_android_env(jniEnv, androidCtx.object());

    QTimer::singleShot(0, NULL, [=]() {
        evolis_device_t* devices;

        _log("-- Starting...");
        if (evolis_get_devices(&devices, 0, 0) > 0) {
            _openCloseTest(&devices[0]);
            _rokTest(&devices[0]);
            _cardMovementsTest(&devices[0]);
            _printerResetTest(&devices[0]);
            _printImage(&devices[0]);
            evolis_free_devices(&devices[0]);
        }
        _log("-- Done!");
    });

    _console = new QTextEdit();
    _console->setReadOnly(true);

    _autoScrollCb = new QCheckBox();
    _autoScrollCb->setText("Auto scroll");
    _autoScrollCb->setChecked(true);

    QWidget window;
    QVBoxLayout layout(&window);
    layout.addWidget(_console);
    layout.addWidget(_autoScrollCb);
    window.show();

    return app.exec();
}
