#include <string.h>
#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AVANSIA;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    avansia_status_infos2_t asi;
    avansia_sense_t as;
    size_t n;
    int r;

    r = avansia_get_printer_status_infos2(printer, &asi, sizeof(asi), &n, &as, sizeof(as), &n);
    printf("r=%d", r);

    avansia_status_t ast;
    r = avansia_status(printer, &ast);
    printf("r=%d", r);

    printf(">>>> %d", memcmp(&(ast.infos), &asi, sizeof(asi)));
    printf(">>>> %d", memcmp(&(ast.sense), &as, sizeof(as)));
}
