#include <evolis.h>
#include <string.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 1;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_mag_tracks_t tracks;

    evolis_mag_init(&tracks);
    strcpy(tracks.tracks[0], "0123456789AZERTYUIOPMLKJHGFDSQWXCVBN12345678912345123456789012345ABKIYTRLM");
    strcpy(tracks.tracks[1], "1234567891234567891234567891234567891");
    strcpy(tracks.tracks[2], "1234567891234567891234567891234567891234567891231234567891234567891234567891234567891234567891231234");
    printf("write() -> %d", evolis_mag_write(printer, &tracks));

    evolis_mag_init(&tracks);
    printf("read() -> %d", evolis_mag_read(printer, &tracks));
    printf("     0 -> %s", tracks.tracks[0]);
    printf("     1 -> %s", tracks.tracks[1]);
    printf("     2 -> %s", tracks.tracks[2]);

    evolis_eject(printer);
}
