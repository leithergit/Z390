#include <evolis.h>

evolis_type_t g_printer_type = EVOLIS_TY_AUTO;
int g_printer_enabled = 0;

void example(evolis_t* printer, const char* bmp, size_t bmpSize)
{
    EVOLIS_UNUSED_ATTR(printer);
    EVOLIS_UNUSED_ATTR(bmp);
    EVOLIS_UNUSED_ATTR(bmpSize);
    evolis_image_t* img;

    if ((img = evolis_image_new()) != NULL) {
        evolis_draw_imagep(img, "resources/front.bmp", 0);
        evolis_renderp(img, "designed.jpg");
        evolis_image_delete(img);
    }
}
