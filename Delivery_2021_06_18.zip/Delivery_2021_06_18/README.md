# GWI's CLithographPrinter

The delivery provide:

1. CLithographPrinter for Zenius (Android platform) :
   The package contains a library that can be use to connect to Zenius printer
   under Android via USB.

   Please ensure calling extra commands "setAndroidContext" and
   "setJavaNativeInterface" to correctly set the Android env.

2. It contains a new extra command named "setPrintOption" that can
   be use to set printing options (customize black printing, brightness,
   contrast, etc...).

## Folders description

- gwi-lithographprinter-android-22-2021-06-18.zip
  The archive provides headers, library for Android.