# Delivery 2021/05/17

## Description

The delivery fixes a memory leak issues when communicating with the printer.

To open a connection you can either use `evolis_get_devices()` and
`evolis_open()` functions or, if you know the printer model, use a uri like
"usb://EVOLIS/Zenius" with `evolis_open2()`.

Example with `evolis_get_devices()` :
```
#include <evolis/evolis.h>
#include <evolis/android.h>

void my_function(JNIEnv* env, jobject androidCtx)
{
  evolis_device_t* devices;

  evolis_set_android_env(jniEnv, androidCtx);
  if (evolis_get_devices(&devices, 0, 0) > 0) {
    for (int i = 0; devices[i] != NULL; ++i) {
      evolis_device_t* device = &devices[i];
      evolis_t* connection;
      
      connection = evolis_open(device->id, false);
      if (connection != NULL) {
        // your code here
        evolis_close(connection)
      }
    }
    evolis_free_devices(devices);
  }
}
```

Example with printer model (`evolis_open2()`):
```
#include <evolis/evolis.h>
#include <evolis/android.h>

void my_function(JNIEnv* env, jobject androidCtx)
{
  evolis_t* connection;

  evolis_set_android_env(jniEnv, androidCtx);
  connection = evolis_open2("usb://Evolis/Zenius", EVOLIS_TY_EVOLIS);
  if (connection != NULL) {
    // your code here
    evolis_close(connection)
  }
}
```

## Folders description

* evotest.apk: An android application to test libEvolis.
* libevolis-tests.apk: An android application to massively requests the printer.
* libevolis-android-21-2021-05-17.zip: LibEvolis for Android API 21+.
  * include/: Folder with header files
  * lib/: Folder with .so files.
  * examples/: Folder with examples and libevolis-test.apk sources.
  * documentation.pdf: Documentation of libEvolis.
